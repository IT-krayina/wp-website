<?php
/**
 * The main template file.
 *
 * @package ThinkUpThemes
 */

?>
This is index.php!