<?php
/**
 * The Home page template file. Loads archive.php when front page display settings are set to show posts.
 *
 * @package ThinkUpThemes
 */

	include( get_archive_template() );

?>