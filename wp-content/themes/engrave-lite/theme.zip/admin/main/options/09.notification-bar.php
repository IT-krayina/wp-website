<?php
/**
 * Notification bar functions.
 *
 * @package ThinkUpThemes
 */

//----------------------------------------------------------------------------------
//	ENABLE NOTIFICATION BAR - PREMIUM FEATURE
//----------------------------------------------------------------------------------


?>